# Build

Use `nix` or install the dependencies listed in `default.nix`.

Then `nix-shell` and `make` or `nix-build`.

Two lights (point and sphere) with 64 samples per pixel:

![Result](image_pointlight.png)
![Result](image_spherelight.png)
