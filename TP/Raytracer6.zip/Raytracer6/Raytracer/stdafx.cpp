// stdafx.cpp : fichier source incluant simplement les fichiers Include standard
// $safeprojectname$.pch représente l'en-tête précompilé
// stdafx.obj contient les informations de type précompilées

#include "stdafx.h"

// TODO: faites référence aux en-têtes supplémentaires nécessaires dans STDAFX.H
// absents de ce fichier
